"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import AppShell from "@/components/public/AppShell";
import { getPublicFishList } from "@/lib/api";
import { FishSpeciesRow } from "@/types/fish";

const fallbackTopFish = ["Tilapia", "Snakehead", "Gourami", "Goldfish", "Catfish"];

const toSlug = (value: string) =>
  value
    .toLowerCase()
    .trim()
    .replace(/_/g, " ")
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/[\s-]+/g, "-")
    .replace(/^-|-$/g, "");

export default function HomePage() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<FishSpeciesRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const res = await getPublicFishList();
        setRows(res.data || []);
      } catch {
        setRows([]);
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  const topRows = useMemo(() => rows.slice(0, 6), [rows]);

  const submitSearch: React.FormEventHandler<HTMLFormElement> = (event) => {
    event.preventDefault();
    router.push(`/fish${q.trim() ? `?q=${encodeURIComponent(q.trim())}` : ""}`);
  };

  return (
    <AppShell
      title="AquaSmart ML"
      subtitle="Fish search engine"
    >
      <section className="rounded-[32px] border border-slate-100 bg-white/95 p-8 shadow-sm backdrop-blur-sm">
        <div className="space-y-6">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-400">Start here</p>
            <h2 className="mt-2 text-3xl font-extrabold text-slate-900 sm:text-4xl">
              Explore fish species and care tips.
            </h2>
            <p className="mt-3 text-lg leading-7 text-slate-500">
              Search by name or upload a picture to identify the fish instantly.
            </p>
          </div>
          <form onSubmit={submitSearch} className="grid gap-4 sm:grid-cols-[1fr_auto]">
            <input
              type="text"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search fish name or keyword"
              className="h-14 w-full rounded-2xl border border-slate-200 bg-slate-50 px-6 text-base text-slate-900 shadow-inner focus:border-blue-500 focus:outline-none"
            />
            <div className="grid gap-3 sm:grid-cols-2 min-w-[280px]">
              <button
                type="button"
                onClick={() => router.push("/identify")}
                className="inline-flex h-14 items-center justify-center rounded-2xl border border-slate-200 bg-white text-base font-semibold text-slate-700 transition hover:bg-slate-50 hover:shadow-sm"
              >
                📷 Identify
              </button>
              <button
                type="submit"
                className="inline-flex h-14 items-center justify-center rounded-2xl bg-blue-600 text-base font-semibold text-white shadow-md transition hover:bg-blue-700 hover:shadow-lg"
              >
                Search
              </button>
            </div>
          </form>
        </div>
      </section>

      <section className="space-y-6 pt-4">
        <div className="flex items-center justify-between gap-3 px-2">
          <div>
            <h3 className="text-xl font-bold text-slate-900">Top Searched Fish</h3>
            <p className="text-sm text-slate-500 mt-1">Popular results based on recent searches.</p>
          </div>
          <Link
            href="/fish"
            className="text-sm font-bold text-blue-600 transition hover:text-blue-700 hover:underline"
          >
            See all catalogs &rarr;
          </Link>
        </div>

        {loading ? (
          <div className="rounded-[32px] border border-slate-100 bg-white p-8 text-center text-slate-500 shadow-sm animate-pulse">
            Loading fish directory...
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {(topRows.length > 0 ? topRows : fallbackTopFish.map((name) => ({ id: name, name, slug: toSlug(name), category: "General" as const })) ).map((fish) => (
              <Link
                key={fish.id}
                href={`/fish/${fish.slug || toSlug(fish.name)}`}
                className="group flex flex-col overflow-hidden rounded-[24px] border border-slate-100 bg-white p-5 shadow-sm transition-all hover:-translate-y-1 hover:shadow-md hover:border-blue-100"
              >
                <div className="flex items-center gap-5">
                  <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-slate-50 text-xl font-semibold text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
                    🐟
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-lg font-bold text-slate-900 group-hover:text-blue-700 transition-colors">{fish.name}</p>
                    <p className="mt-1 text-sm text-slate-500 bg-slate-100 inline-block px-2.5 py-0.5 rounded-full">{fish.category || "General"}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>
    </AppShell>
  );
}
